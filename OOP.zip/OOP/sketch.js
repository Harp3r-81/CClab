let c = [];
let r = [];
function setup() {
  createCanvas(400, 400);
}
function mousePressed() {
  let ran = random(0.5,1)
  c.push(new Cloud(mouseX, mouseY, ran));
  
}



function draw() {
  background(220);
  if(mouseIsPressed){
    r.push(new Rain(mouseX ,mouseY))
  }
  for (let i = 0; i < r.length; i++) {
   
    r[i].updateRain();
    r[i].displayRain();
     if(r[i].isOut){
      r.splice(i,1)
    }
  }
  console.log(r.length)
  
  for (let i = 0; i < c.length; i++) {
    c[i].update();
    c[i].display();
    if(c[i].isOut){
      c.splice(i,1)
    }
  }
  console.log(c.length)
 
  
}

